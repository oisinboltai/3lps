"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const versions = [
  { href: "/", label: "V1", desc: "Clean SaaS" },
  { href: "/v2", label: "V2", desc: "Modern Startup" },
  { href: "/v3", label: "V3", desc: "Marketing" },
];

export default function Nav() {
  const pathname = usePathname();

  return (
    <nav
      style={{
        position: "fixed",
        bottom: "24px",
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: 1000,
        background: "rgba(10,10,10,0.85)",
        backdropFilter: "blur(16px)",
        border: "1px solid rgba(255,255,255,0.12)",
        borderRadius: "100px",
        padding: "6px",
        display: "flex",
        gap: "4px",
        boxShadow: "0 8px 40px rgba(0,0,0,0.4)",
      }}
    >
      {versions.map(({ href, label, desc }) => {
        const isActive = pathname === href;
        return (
          <Link
            key={href}
            href={href}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "6px",
              padding: "8px 18px",
              borderRadius: "100px",
              textDecoration: "none",
              transition: "all 0.2s ease",
              background: isActive ? "rgba(255,255,255,0.95)" : "transparent",
              color: isActive ? "#0a0a0a" : "rgba(255,255,255,0.65)",
            }}
          >
            <span
              style={{
                fontFamily: "monospace",
                fontSize: "11px",
                fontWeight: 700,
                letterSpacing: "0.08em",
              }}
            >
              {label}
            </span>
            <span
              style={{
                fontSize: "11px",
                fontWeight: 400,
                opacity: isActive ? 0.6 : 0.5,
              }}
            >
              {desc}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}
