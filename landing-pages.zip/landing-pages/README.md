# Landing Pages

Three distinct landing page variants in a single Next.js (App Router) project.

## Routes

| Route | Page | Style |
|-------|------|-------|
| `/` | Landing V1 | Clean SaaS — serif typography, editorial layout |
| `/v2` | Landing V2 | Modern Startup — dark, gradient, AI-native |
| `/v3` | Landing V3 | High-conversion Marketing — bold, direct-response |

A floating nav pill at the bottom of the screen lets you switch between all three.

## Tech Stack

- **Next.js 14** (App Router)
- **TypeScript**
- **Tailwind CSS**
- Zero external UI libraries

## Development

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Deploy to Vercel

Push to GitHub, then import the repo at [vercel.com/new](https://vercel.com/new). Vercel will auto-detect Next.js and deploy with zero config.

```bash
# Or deploy via CLI
npm i -g vercel
vercel
```

## Project Structure

```
app/
├── layout.tsx        # Root layout with Nav
├── globals.css       # Tailwind base styles
├── page.tsx          # V1 — Clean SaaS
├── v2/
│   └── page.tsx      # V2 — Modern Startup
└── v3/
    └── page.tsx      # V3 — High-conversion Marketing
components/
└── nav.tsx           # Floating version switcher
```
