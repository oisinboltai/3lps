import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Streamline — The SaaS Platform Built for Scale",
};

const benefits = [
  {
    icon: "⚡",
    title: "10× Faster Workflows",
    desc: "Automate repetitive tasks and reclaim hours every week. Your team ships more without working more.",
  },
  {
    icon: "🔒",
    title: "Enterprise-Grade Security",
    desc: "SOC 2 Type II certified. End-to-end encryption. Your data never leaves your control.",
  },
  {
    icon: "📈",
    title: "Real-Time Analytics",
    desc: "See exactly what's working. Live dashboards surface insights before they become problems.",
  },
];

const logos = ["Acme Corp", "Orbit", "Velox", "Meridian", "Flux", "Stratos"];

export default function V1() {
  return (
    <div
      style={{
        fontFamily:
          "'Georgia', 'Times New Roman', serif",
        color: "#1a1a2e",
        background: "#fafaf8",
        minHeight: "100vh",
      }}
    >
      {/* Top Nav Bar */}
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "20px 48px",
          borderBottom: "1px solid #e8e8e4",
          background: "#fafaf8",
          position: "sticky",
          top: 0,
          zIndex: 100,
        }}
      >
        <div
          style={{
            fontFamily: "'Georgia', serif",
            fontSize: "20px",
            fontWeight: 700,
            letterSpacing: "-0.02em",
            color: "#0d0d1a",
          }}
        >
          Streamline
        </div>
        <nav style={{ display: "flex", gap: "32px", alignItems: "center" }}>
          {["Product", "Pricing", "Docs", "Blog"].map((item) => (
            <a
              key={item}
              href="#"
              style={{
                fontFamily: "'Helvetica Neue', sans-serif",
                fontSize: "14px",
                color: "#555",
                textDecoration: "none",
                letterSpacing: "0.01em",
              }}
            >
              {item}
            </a>
          ))}
          <button
            style={{
              background: "#0d0d1a",
              color: "#fff",
              border: "none",
              borderRadius: "6px",
              padding: "9px 20px",
              fontFamily: "'Helvetica Neue', sans-serif",
              fontSize: "14px",
              cursor: "pointer",
              letterSpacing: "0.01em",
            }}
          >
            Get Started
          </button>
        </nav>
      </header>

      {/* Hero */}
      <section
        style={{
          maxWidth: "800px",
          margin: "0 auto",
          padding: "100px 48px 80px",
          textAlign: "center",
        }}
      >
        <div
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "8px",
            background: "#f0f0ec",
            border: "1px solid #ddd",
            borderRadius: "100px",
            padding: "6px 14px",
            marginBottom: "32px",
          }}
        >
          <span
            style={{
              width: "6px",
              height: "6px",
              borderRadius: "50%",
              background: "#22c55e",
              display: "inline-block",
            }}
          />
          <span
            style={{
              fontFamily: "'Helvetica Neue', sans-serif",
              fontSize: "12px",
              color: "#555",
              letterSpacing: "0.04em",
              textTransform: "uppercase",
            }}
          >
            Now in public beta
          </span>
        </div>

        <h1
          style={{
            fontSize: "clamp(40px, 6vw, 68px)",
            fontWeight: 700,
            lineHeight: 1.1,
            letterSpacing: "-0.03em",
            color: "#0d0d1a",
            marginBottom: "24px",
          }}
        >
          The operations platform
          <br />
          <em style={{ fontStyle: "italic", color: "#555" }}>
            your team will love.
          </em>
        </h1>

        <p
          style={{
            fontFamily: "'Helvetica Neue', sans-serif",
            fontSize: "18px",
            lineHeight: 1.7,
            color: "#666",
            maxWidth: "520px",
            margin: "0 auto 40px",
          }}
        >
          Streamline unifies your workflows, automates the tedious, and gives
          every team member a single place to get work done.
        </p>

        <div style={{ display: "flex", gap: "12px", justifyContent: "center" }}>
          <button
            style={{
              background: "#0d0d1a",
              color: "#fff",
              border: "none",
              borderRadius: "8px",
              padding: "14px 28px",
              fontSize: "15px",
              fontFamily: "'Helvetica Neue', sans-serif",
              cursor: "pointer",
              letterSpacing: "0.01em",
            }}
          >
            Start free trial
          </button>
          <button
            style={{
              background: "transparent",
              color: "#0d0d1a",
              border: "1px solid #ccc",
              borderRadius: "8px",
              padding: "14px 28px",
              fontSize: "15px",
              fontFamily: "'Helvetica Neue', sans-serif",
              cursor: "pointer",
            }}
          >
            Watch demo →
          </button>
        </div>

        <p
          style={{
            marginTop: "16px",
            fontFamily: "'Helvetica Neue', sans-serif",
            fontSize: "13px",
            color: "#999",
          }}
        >
          No credit card required · Cancel anytime
        </p>
      </section>

      {/* Social Proof Logos */}
      <section
        style={{
          borderTop: "1px solid #e8e8e4",
          borderBottom: "1px solid #e8e8e4",
          padding: "32px 48px",
        }}
      >
        <p
          style={{
            textAlign: "center",
            fontFamily: "'Helvetica Neue', sans-serif",
            fontSize: "12px",
            letterSpacing: "0.1em",
            textTransform: "uppercase",
            color: "#aaa",
            marginBottom: "24px",
          }}
        >
          Trusted by teams at
        </p>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            flexWrap: "wrap",
            gap: "40px",
          }}
        >
          {logos.map((logo) => (
            <span
              key={logo}
              style={{
                fontFamily: "'Georgia', serif",
                fontSize: "16px",
                fontWeight: 700,
                color: "#bbb",
                letterSpacing: "-0.02em",
              }}
            >
              {logo}
            </span>
          ))}
        </div>
      </section>

      {/* Benefits */}
      <section
        style={{
          maxWidth: "1100px",
          margin: "0 auto",
          padding: "100px 48px",
        }}
      >
        <h2
          style={{
            textAlign: "center",
            fontSize: "clamp(28px, 4vw, 42px)",
            fontWeight: 700,
            letterSpacing: "-0.03em",
            color: "#0d0d1a",
            marginBottom: "16px",
          }}
        >
          Everything your team needs.
          <br />
          <em style={{ fontStyle: "italic", color: "#888", fontWeight: 400 }}>
            Nothing they don't.
          </em>
        </h2>
        <p
          style={{
            textAlign: "center",
            fontFamily: "'Helvetica Neue', sans-serif",
            fontSize: "16px",
            color: "#777",
            marginBottom: "64px",
          }}
        >
          Built for modern operations teams who need speed without complexity.
        </p>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: "2px",
            background: "#e8e8e4",
            border: "1px solid #e8e8e4",
            borderRadius: "12px",
            overflow: "hidden",
          }}
        >
          {benefits.map((b) => (
            <div
              key={b.title}
              style={{
                background: "#fafaf8",
                padding: "48px 40px",
              }}
            >
              <div style={{ fontSize: "32px", marginBottom: "20px" }}>
                {b.icon}
              </div>
              <h3
                style={{
                  fontFamily: "'Georgia', serif",
                  fontSize: "20px",
                  fontWeight: 700,
                  letterSpacing: "-0.02em",
                  color: "#0d0d1a",
                  marginBottom: "12px",
                }}
              >
                {b.title}
              </h3>
              <p
                style={{
                  fontFamily: "'Helvetica Neue', sans-serif",
                  fontSize: "14px",
                  lineHeight: 1.7,
                  color: "#666",
                }}
              >
                {b.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Metrics Social Proof */}
      <section
        style={{
          background: "#0d0d1a",
          color: "#fff",
          padding: "80px 48px",
        }}
      >
        <div
          style={{
            maxWidth: "900px",
            margin: "0 auto",
            textAlign: "center",
          }}
        >
          <p
            style={{
              fontFamily: "'Helvetica Neue', sans-serif",
              fontSize: "12px",
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              color: "#666",
              marginBottom: "48px",
            }}
          >
            By the numbers
          </p>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(3, 1fr)",
              gap: "48px",
            }}
          >
            {[
              { stat: "40,000+", label: "Teams worldwide" },
              { stat: "99.97%", label: "Uptime SLA" },
              { stat: "4.9 / 5", label: "Average rating" },
            ].map(({ stat, label }) => (
              <div key={label}>
                <div
                  style={{
                    fontFamily: "'Georgia', serif",
                    fontSize: "clamp(36px, 5vw, 56px)",
                    fontWeight: 700,
                    letterSpacing: "-0.03em",
                    marginBottom: "8px",
                  }}
                >
                  {stat}
                </div>
                <div
                  style={{
                    fontFamily: "'Helvetica Neue', sans-serif",
                    fontSize: "14px",
                    color: "#888",
                  }}
                >
                  {label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section
        style={{
          maxWidth: "640px",
          margin: "0 auto",
          padding: "120px 48px 140px",
          textAlign: "center",
        }}
      >
        <h2
          style={{
            fontSize: "clamp(32px, 5vw, 52px)",
            fontWeight: 700,
            letterSpacing: "-0.03em",
            color: "#0d0d1a",
            marginBottom: "20px",
            lineHeight: 1.1,
          }}
        >
          Ready to streamline
          <br />
          how you work?
        </h2>
        <p
          style={{
            fontFamily: "'Helvetica Neue', sans-serif",
            fontSize: "16px",
            color: "#777",
            marginBottom: "36px",
            lineHeight: 1.6,
          }}
        >
          Join thousands of teams already saving hours every week. Get started
          in under five minutes.
        </p>
        <button
          style={{
            background: "#0d0d1a",
            color: "#fff",
            border: "none",
            borderRadius: "8px",
            padding: "16px 36px",
            fontSize: "16px",
            fontFamily: "'Helvetica Neue', sans-serif",
            cursor: "pointer",
            letterSpacing: "0.01em",
          }}
        >
          Start your free trial →
        </button>
        <p
          style={{
            marginTop: "16px",
            fontFamily: "'Helvetica Neue', sans-serif",
            fontSize: "13px",
            color: "#bbb",
          }}
        >
          14-day free trial · No credit card · Cancel anytime
        </p>
      </section>
    </div>
  );
}
