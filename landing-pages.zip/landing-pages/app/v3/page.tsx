import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "PEAK — Stop Losing Revenue to Outdated Processes",
};

const pains = [
  {
    emoji: "😤",
    text: "Your team is buried in status updates instead of actual work",
  },
  {
    emoji: "🕳️",
    text: "Deals fall through cracks nobody even knew existed",
  },
  {
    emoji: "🔥",
    text: "Every handoff is a game of telephone that ends badly",
  },
  {
    emoji: "💸",
    text: "You're paying for 7 tools that still don't talk to each other",
  },
];

const testimonials = [
  {
    quote:
      "We closed 34% more deals the quarter after switching to PEAK. I wish we'd done it two years ago.",
    name: "Marcus T.",
    role: "VP Sales, Finco Group",
    rating: 5,
  },
  {
    quote:
      "Onboarding used to take 3 weeks. Now it's 3 days. The ops team finally stopped hating Mondays.",
    name: "Priya M.",
    role: "Head of Operations, Launchpad Inc.",
    rating: 5,
  },
  {
    quote:
      "I was skeptical of another SaaS promise. But PEAK actually delivered. Revenue is up, stress is down.",
    name: "Jordan K.",
    role: "Founder & CEO, Axon Logistics",
    rating: 5,
  },
];

export default function V3() {
  return (
    <div
      style={{
        fontFamily: "'Arial Black', 'Helvetica Neue', Arial, sans-serif",
        background: "#fff",
        color: "#111",
        minHeight: "100vh",
      }}
    >
      {/* Urgency bar */}
      <div
        style={{
          background: "#dc2626",
          color: "#fff",
          textAlign: "center",
          padding: "10px 24px",
          fontSize: "13px",
          fontWeight: 700,
          letterSpacing: "0.04em",
          textTransform: "uppercase",
        }}
      >
        🔥 Limited offer: 30% off annual plans — ends Friday midnight
      </div>

      {/* Header */}
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "16px 48px",
          borderBottom: "3px solid #111",
          background: "#fff",
          position: "sticky",
          top: 0,
          zIndex: 100,
        }}
      >
        <div
          style={{
            fontSize: "24px",
            fontWeight: 900,
            letterSpacing: "-0.04em",
            textTransform: "uppercase",
            color: "#111",
          }}
        >
          PEAK<span style={{ color: "#dc2626" }}>.</span>
        </div>
        <button
          style={{
            background: "#dc2626",
            color: "#fff",
            border: "3px solid #111",
            borderRadius: "4px",
            padding: "10px 24px",
            fontSize: "13px",
            fontWeight: 900,
            cursor: "pointer",
            textTransform: "uppercase",
            letterSpacing: "0.06em",
            boxShadow: "3px 3px 0 #111",
          }}
        >
          Claim Offer Now →
        </button>
      </header>

      {/* Hero */}
      <section
        style={{
          background: "#111",
          color: "#fff",
          padding: "80px 48px",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            top: 0,
            right: 0,
            width: "50%",
            height: "100%",
            background:
              "repeating-linear-gradient(45deg, rgba(220,38,38,0.05), rgba(220,38,38,0.05) 1px, transparent 1px, transparent 20px)",
            pointerEvents: "none",
          }}
        />

        <div style={{ maxWidth: "800px", position: "relative" }}>
          <div
            style={{
              display: "inline-block",
              background: "#dc2626",
              color: "#fff",
              padding: "6px 14px",
              fontSize: "12px",
              fontWeight: 900,
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              marginBottom: "28px",
              borderRadius: "3px",
            }}
          >
            The #1 revenue ops platform
          </div>

          <h1
            style={{
              fontSize: "clamp(44px, 7vw, 84px)",
              fontWeight: 900,
              lineHeight: 0.95,
              letterSpacing: "-0.04em",
              marginBottom: "28px",
              textTransform: "uppercase",
            }}
          >
            Stop losing
            <br />
            <span style={{ color: "#dc2626" }}>revenue</span>
            <br />
            to broken ops.
          </h1>

          <p
            style={{
              fontSize: "18px",
              lineHeight: 1.6,
              color: "rgba(255,255,255,0.65)",
              maxWidth: "520px",
              marginBottom: "44px",
              fontFamily: "'Helvetica Neue', Arial, sans-serif",
              fontWeight: 400,
            }}
          >
            Most companies leave 20-40% of potential revenue on the table —
            not from bad products, but from broken processes. PEAK fixes that.
            Fast.
          </p>

          <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
            <button
              style={{
                background: "#dc2626",
                color: "#fff",
                border: "3px solid #dc2626",
                borderRadius: "4px",
                padding: "16px 36px",
                fontSize: "16px",
                fontWeight: 900,
                cursor: "pointer",
                textTransform: "uppercase",
                letterSpacing: "0.05em",
                boxShadow: "4px 4px 0 rgba(220,38,38,0.4)",
              }}
            >
              Fix My Revenue Ops →
            </button>
            <button
              style={{
                background: "transparent",
                color: "#fff",
                border: "3px solid rgba(255,255,255,0.3)",
                borderRadius: "4px",
                padding: "16px 36px",
                fontSize: "16px",
                fontWeight: 700,
                cursor: "pointer",
                fontFamily: "'Helvetica Neue', Arial, sans-serif",
              }}
            >
              See case studies
            </button>
          </div>

          <div
            style={{
              marginTop: "32px",
              display: "flex",
              gap: "32px",
              flexWrap: "wrap",
            }}
          >
            {[
              "✓ No long-term contracts",
              "✓ Live in 48 hours",
              "✓ 60-day money back",
            ].map((item) => (
              <span
                key={item}
                style={{
                  fontFamily: "'Helvetica Neue', Arial, sans-serif",
                  fontSize: "13px",
                  color: "rgba(255,255,255,0.5)",
                  fontWeight: 400,
                }}
              >
                {item}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Pain Points */}
      <section
        style={{ padding: "80px 48px", background: "#fff" }}
      >
        <div style={{ maxWidth: "900px", margin: "0 auto" }}>
          <div
            style={{
              borderLeft: "5px solid #dc2626",
              paddingLeft: "24px",
              marginBottom: "48px",
            }}
          >
            <h2
              style={{
                fontSize: "clamp(28px, 4vw, 44px)",
                fontWeight: 900,
                letterSpacing: "-0.03em",
                textTransform: "uppercase",
                lineHeight: 1.05,
              }}
            >
              Does this sound
              <br />
              <span style={{ color: "#dc2626" }}>painfully familiar?</span>
            </h2>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(2, 1fr)",
              gap: "16px",
            }}
          >
            {pains.map((pain) => (
              <div
                key={pain.text}
                style={{
                  border: "2px solid #111",
                  borderRadius: "8px",
                  padding: "28px",
                  display: "flex",
                  gap: "16px",
                  alignItems: "flex-start",
                  background: "#fafafa",
                }}
              >
                <span style={{ fontSize: "28px", flexShrink: 0 }}>
                  {pain.emoji}
                </span>
                <p
                  style={{
                    fontFamily: "'Helvetica Neue', Arial, sans-serif",
                    fontSize: "15px",
                    lineHeight: 1.55,
                    fontWeight: 500,
                    color: "#333",
                    margin: 0,
                  }}
                >
                  {pain.text}
                </p>
              </div>
            ))}
          </div>

          <div
            style={{
              marginTop: "48px",
              background: "#fff9f9",
              border: "3px solid #dc2626",
              borderRadius: "8px",
              padding: "32px 36px",
            }}
          >
            <p
              style={{
                fontFamily: "'Helvetica Neue', Arial, sans-serif",
                fontSize: "18px",
                lineHeight: 1.6,
                color: "#111",
                fontWeight: 600,
                margin: 0,
              }}
            >
              <strong style={{ color: "#dc2626" }}>
                You're not the problem.
              </strong>{" "}
              Your tools are. The average revenue team loses 14 hours per week
              to process failure. That's{" "}
              <strong>$82,000 in lost productivity per employee per year.</strong>
            </p>
          </div>
        </div>
      </section>

      {/* Solution */}
      <section
        style={{
          padding: "80px 48px",
          background: "#111",
          color: "#fff",
        }}
      >
        <div style={{ maxWidth: "900px", margin: "0 auto" }}>
          <div
            style={{
              display: "inline-block",
              border: "2px solid #dc2626",
              borderRadius: "4px",
              padding: "5px 12px",
              fontSize: "11px",
              fontWeight: 900,
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              color: "#dc2626",
              marginBottom: "28px",
            }}
          >
            The solution
          </div>

          <h2
            style={{
              fontSize: "clamp(28px, 4vw, 48px)",
              fontWeight: 900,
              letterSpacing: "-0.03em",
              textTransform: "uppercase",
              marginBottom: "48px",
              lineHeight: 1.05,
            }}
          >
            PEAK rebuilds your ops
            <br />
            <span style={{ color: "#dc2626" }}>from the ground up.</span>
          </h2>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(3, 1fr)",
              gap: "24px",
            }}
          >
            {[
              {
                num: "1",
                title: "Audit & Map",
                desc: "We map every handoff, bottleneck, and failure point in your current workflow in 24 hours.",
              },
              {
                num: "2",
                title: "Build & Automate",
                desc: "PEAK deploys your optimized ops stack — automating 80% of manual work within a week.",
              },
              {
                num: "3",
                title: "Measure & Scale",
                desc: "Live revenue dashboards show exactly where you're winning and where to double down.",
              },
            ].map((step) => (
              <div
                key={step.num}
                style={{
                  border: "2px solid rgba(255,255,255,0.12)",
                  borderRadius: "8px",
                  padding: "32px 28px",
                }}
              >
                <div
                  style={{
                    width: "44px",
                    height: "44px",
                    background: "#dc2626",
                    borderRadius: "6px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontWeight: 900,
                    fontSize: "20px",
                    marginBottom: "20px",
                  }}
                >
                  {step.num}
                </div>
                <h3
                  style={{
                    fontSize: "18px",
                    fontWeight: 900,
                    textTransform: "uppercase",
                    letterSpacing: "-0.01em",
                    marginBottom: "12px",
                  }}
                >
                  {step.title}
                </h3>
                <p
                  style={{
                    fontFamily: "'Helvetica Neue', Arial, sans-serif",
                    fontSize: "14px",
                    lineHeight: 1.65,
                    color: "rgba(255,255,255,0.5)",
                    margin: 0,
                  }}
                >
                  {step.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section style={{ padding: "80px 48px", background: "#f8f8f8" }}>
        <div style={{ maxWidth: "1000px", margin: "0 auto" }}>
          <h2
            style={{
              fontSize: "clamp(28px, 4vw, 44px)",
              fontWeight: 900,
              letterSpacing: "-0.03em",
              textTransform: "uppercase",
              textAlign: "center",
              marginBottom: "8px",
            }}
          >
            Real results.
          </h2>
          <p
            style={{
              textAlign: "center",
              fontFamily: "'Helvetica Neue', Arial, sans-serif",
              fontSize: "15px",
              color: "#777",
              marginBottom: "52px",
            }}
          >
            From companies that were exactly where you are now.
          </p>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(3, 1fr)",
              gap: "20px",
            }}
          >
            {testimonials.map((t) => (
              <div
                key={t.name}
                style={{
                  background: "#fff",
                  border: "2px solid #111",
                  borderRadius: "8px",
                  padding: "32px",
                  boxShadow: "4px 4px 0 #111",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    gap: "3px",
                    marginBottom: "16px",
                  }}
                >
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <span key={i} style={{ color: "#dc2626", fontSize: "16px" }}>
                      ★
                    </span>
                  ))}
                </div>
                <p
                  style={{
                    fontFamily: "'Helvetica Neue', Arial, sans-serif",
                    fontSize: "14px",
                    lineHeight: 1.65,
                    color: "#333",
                    marginBottom: "20px",
                    fontStyle: "italic",
                  }}
                >
                  "{t.quote}"
                </p>
                <div>
                  <div
                    style={{
                      fontWeight: 900,
                      fontSize: "14px",
                      textTransform: "uppercase",
                      letterSpacing: "0.02em",
                    }}
                  >
                    {t.name}
                  </div>
                  <div
                    style={{
                      fontFamily: "'Helvetica Neue', Arial, sans-serif",
                      fontSize: "12px",
                      color: "#888",
                      marginTop: "2px",
                    }}
                  >
                    {t.role}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section
        style={{
          background: "#dc2626",
          color: "#fff",
          padding: "100px 48px 120px",
          textAlign: "center",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            background:
              "repeating-linear-gradient(45deg, rgba(0,0,0,0.04), rgba(0,0,0,0.04) 1px, transparent 1px, transparent 24px)",
            pointerEvents: "none",
          }}
        />
        <div style={{ position: "relative" }}>
          <h2
            style={{
              fontSize: "clamp(40px, 7vw, 80px)",
              fontWeight: 900,
              letterSpacing: "-0.04em",
              lineHeight: 0.95,
              textTransform: "uppercase",
              marginBottom: "28px",
            }}
          >
            Your competition
            <br />
            won't wait.
          </h2>
          <p
            style={{
              fontFamily: "'Helvetica Neue', Arial, sans-serif",
              fontSize: "18px",
              lineHeight: 1.6,
              color: "rgba(255,255,255,0.8)",
              maxWidth: "480px",
              margin: "0 auto 44px",
              fontWeight: 400,
            }}
          >
            Every week you delay costs you revenue, talent, and market
            position. Start fixing your ops today — risk-free.
          </p>

          <button
            style={{
              background: "#fff",
              color: "#dc2626",
              border: "3px solid #fff",
              borderRadius: "6px",
              padding: "18px 44px",
              fontSize: "18px",
              fontWeight: 900,
              cursor: "pointer",
              textTransform: "uppercase",
              letterSpacing: "0.05em",
              boxShadow: "5px 5px 0 rgba(0,0,0,0.2)",
            }}
          >
            Get PEAK Now — 30% Off →
          </button>

          <div
            style={{
              marginTop: "20px",
              fontFamily: "'Helvetica Neue', Arial, sans-serif",
              fontSize: "13px",
              color: "rgba(255,255,255,0.6)",
            }}
          >
            60-day full money-back guarantee · No questions asked
          </div>

          <div
            style={{
              marginTop: "48px",
              display: "flex",
              justifyContent: "center",
              gap: "48px",
              flexWrap: "wrap",
            }}
          >
            {[
              { num: "8,400+", label: "Companies scaled" },
              { num: "$2.1B", label: "Revenue recovered" },
              { num: "48hr", label: "Time to live" },
            ].map(({ num, label }) => (
              <div key={label}>
                <div
                  style={{
                    fontSize: "clamp(28px, 4vw, 42px)",
                    fontWeight: 900,
                    letterSpacing: "-0.03em",
                  }}
                >
                  {num}
                </div>
                <div
                  style={{
                    fontFamily: "'Helvetica Neue', Arial, sans-serif",
                    fontSize: "13px",
                    color: "rgba(255,255,255,0.6)",
                    textTransform: "uppercase",
                    letterSpacing: "0.06em",
                  }}
                >
                  {label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
