import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Nova — AI-Powered Collaboration for the Future of Work",
};

const features = [
  {
    icon: "✦",
    title: "AI Co-pilot",
    desc: "Context-aware suggestions that learn from your team's patterns and surface the right action at the right time.",
    color: "#a78bfa",
  },
  {
    icon: "◎",
    title: "Multiplayer Everything",
    desc: "Real-time collaboration on any object — docs, boards, tasks, code. Presence without limits.",
    color: "#38bdf8",
  },
  {
    icon: "⬡",
    title: "Universal Integrations",
    desc: "Connect 200+ tools. Trigger automations. Sync data bidirectionally without writing a line of code.",
    color: "#34d399",
  },
  {
    icon: "⊕",
    title: "Permission Architecture",
    desc: "Granular roles, guest access, and audit logs built for enterprise compliance from day one.",
    color: "#fb923c",
  },
  {
    icon: "▲",
    title: "Instant Deployment",
    desc: "From zero to production in 60 seconds. Docker-native, edge-ready, Kubernetes-optional.",
    color: "#f472b6",
  },
  {
    icon: "◈",
    title: "Smart Analytics",
    desc: "Behavioral funnels, team velocity metrics, and burndown forecasting without a data warehouse.",
    color: "#facc15",
  },
];

const steps = [
  {
    num: "01",
    title: "Connect your stack",
    desc: "Plug in GitHub, Slack, Figma, Linear — or any of the 200+ integrations in under a minute.",
  },
  {
    num: "02",
    title: "Invite your team",
    desc: "Roles, workspaces, and guest links are ready instantly. No IT ticket required.",
  },
  {
    num: "03",
    title: "Ship together",
    desc: "Nova learns your workflows and starts surfacing shortcuts, blockers, and opportunities automatically.",
  },
];

export default function V2() {
  return (
    <div
      style={{
        fontFamily: "'Segoe UI', 'SF Pro Display', system-ui, sans-serif",
        background: "#050510",
        color: "#e8e8f0",
        minHeight: "100vh",
        overflowX: "hidden",
      }}
    >
      {/* Nav */}
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "20px 48px",
          position: "sticky",
          top: 0,
          zIndex: 100,
          borderBottom: "1px solid rgba(255,255,255,0.06)",
          background: "rgba(5,5,16,0.8)",
          backdropFilter: "blur(20px)",
        }}
      >
        <div
          style={{
            fontSize: "22px",
            fontWeight: 800,
            letterSpacing: "-0.04em",
            background: "linear-gradient(135deg, #a78bfa, #38bdf8)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          Nova
        </div>
        <nav style={{ display: "flex", gap: "28px", alignItems: "center" }}>
          {["Features", "Pricing", "Changelog", "Docs"].map((item) => (
            <a
              key={item}
              href="#"
              style={{
                fontSize: "14px",
                color: "rgba(232,232,240,0.5)",
                textDecoration: "none",
                letterSpacing: "0.01em",
              }}
            >
              {item}
            </a>
          ))}
          <button
            style={{
              background: "linear-gradient(135deg, #a78bfa, #38bdf8)",
              color: "#050510",
              border: "none",
              borderRadius: "8px",
              padding: "9px 20px",
              fontSize: "13px",
              fontWeight: 700,
              cursor: "pointer",
              letterSpacing: "0.02em",
            }}
          >
            Get early access
          </button>
        </nav>
      </header>

      {/* Hero */}
      <section
        style={{
          position: "relative",
          textAlign: "center",
          padding: "120px 48px 100px",
          overflow: "hidden",
        }}
      >
        {/* Gradient orbs */}
        <div
          style={{
            position: "absolute",
            top: "-200px",
            left: "50%",
            transform: "translateX(-50%)",
            width: "800px",
            height: "600px",
            background:
              "radial-gradient(ellipse at center, rgba(167,139,250,0.2) 0%, rgba(56,189,248,0.1) 40%, transparent 70%)",
            pointerEvents: "none",
          }}
        />
        <div
          style={{
            position: "absolute",
            top: "100px",
            left: "10%",
            width: "400px",
            height: "400px",
            background:
              "radial-gradient(circle, rgba(167,139,250,0.08) 0%, transparent 70%)",
            borderRadius: "50%",
            pointerEvents: "none",
          }}
        />
        <div
          style={{
            position: "absolute",
            top: "50px",
            right: "5%",
            width: "350px",
            height: "350px",
            background:
              "radial-gradient(circle, rgba(56,189,248,0.08) 0%, transparent 70%)",
            borderRadius: "50%",
            pointerEvents: "none",
          }}
        />

        <div style={{ position: "relative", zIndex: 1 }}>
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              background: "rgba(167,139,250,0.1)",
              border: "1px solid rgba(167,139,250,0.3)",
              borderRadius: "100px",
              padding: "6px 16px",
              marginBottom: "36px",
            }}
          >
            <span style={{ fontSize: "11px", color: "#a78bfa" }}>✦</span>
            <span
              style={{
                fontSize: "12px",
                color: "rgba(232,232,240,0.7)",
                letterSpacing: "0.05em",
                textTransform: "uppercase",
              }}
            >
              Backed by Sequoia · Series A
            </span>
          </div>

          <h1
            style={{
              fontSize: "clamp(48px, 7vw, 88px)",
              fontWeight: 900,
              lineHeight: 1.0,
              letterSpacing: "-0.05em",
              marginBottom: "28px",
            }}
          >
            <span
              style={{
                background: "linear-gradient(135deg, #ffffff 30%, #a78bfa)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              The future of
            </span>
            <br />
            <span
              style={{
                background: "linear-gradient(135deg, #a78bfa, #38bdf8)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              team collaboration
            </span>
          </h1>

          <p
            style={{
              fontSize: "18px",
              lineHeight: 1.7,
              color: "rgba(232,232,240,0.55)",
              maxWidth: "540px",
              margin: "0 auto 48px",
            }}
          >
            Nova is the AI-native workspace where engineering, design, and
            product teams converge — and move at the speed of thought.
          </p>

          <div
            style={{
              display: "flex",
              gap: "14px",
              justifyContent: "center",
              flexWrap: "wrap",
            }}
          >
            <button
              style={{
                background: "linear-gradient(135deg, #a78bfa, #38bdf8)",
                color: "#050510",
                border: "none",
                borderRadius: "10px",
                padding: "15px 32px",
                fontSize: "15px",
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Start building free
            </button>
            <button
              style={{
                background: "rgba(255,255,255,0.04)",
                color: "rgba(232,232,240,0.8)",
                border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: "10px",
                padding: "15px 32px",
                fontSize: "15px",
                cursor: "pointer",
              }}
            >
              See it in action ↗
            </button>
          </div>
        </div>
      </section>

      {/* Feature Cards Grid */}
      <section style={{ padding: "40px 48px 100px", maxWidth: "1200px", margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: "64px" }}>
          <h2
            style={{
              fontSize: "clamp(28px, 4vw, 44px)",
              fontWeight: 800,
              letterSpacing: "-0.04em",
              marginBottom: "16px",
            }}
          >
            Everything{" "}
            <span
              style={{
                background: "linear-gradient(135deg, #a78bfa, #38bdf8)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              supercharged.
            </span>
          </h2>
          <p style={{ color: "rgba(232,232,240,0.45)", fontSize: "16px", maxWidth: "460px", margin: "0 auto" }}>
            Every feature was designed to remove friction and amplify what your team does best.
          </p>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: "16px",
          }}
        >
          {features.map((f) => (
            <div
              key={f.title}
              style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: "16px",
                padding: "32px",
                transition: "border-color 0.2s",
              }}
            >
              <div
                style={{
                  fontSize: "24px",
                  color: f.color,
                  marginBottom: "20px",
                  fontWeight: 300,
                }}
              >
                {f.icon}
              </div>
              <h3
                style={{
                  fontSize: "17px",
                  fontWeight: 700,
                  letterSpacing: "-0.02em",
                  marginBottom: "10px",
                  color: "#e8e8f0",
                }}
              >
                {f.title}
              </h3>
              <p
                style={{
                  fontSize: "14px",
                  lineHeight: 1.65,
                  color: "rgba(232,232,240,0.45)",
                }}
              >
                {f.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* How it Works */}
      <section
        style={{
          padding: "80px 48px 100px",
          maxWidth: "900px",
          margin: "0 auto",
        }}
      >
        <div
          style={{
            display: "inline-block",
            background: "rgba(56,189,248,0.1)",
            border: "1px solid rgba(56,189,248,0.2)",
            borderRadius: "6px",
            padding: "4px 12px",
            fontSize: "11px",
            color: "#38bdf8",
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            marginBottom: "32px",
          }}
        >
          How it works
        </div>

        <h2
          style={{
            fontSize: "clamp(28px, 4vw, 44px)",
            fontWeight: 800,
            letterSpacing: "-0.04em",
            marginBottom: "64px",
            lineHeight: 1.1,
          }}
        >
          Up and running
          <br />
          <span style={{ color: "rgba(232,232,240,0.35)" }}>in three steps.</span>
        </h2>

        <div style={{ display: "flex", flexDirection: "column", gap: "0" }}>
          {steps.map((step, i) => (
            <div
              key={step.num}
              style={{
                display: "grid",
                gridTemplateColumns: "80px 1fr",
                gap: "32px",
                alignItems: "start",
                paddingBottom: i < steps.length - 1 ? "48px" : "0",
                borderBottom:
                  i < steps.length - 1
                    ? "1px solid rgba(255,255,255,0.06)"
                    : "none",
                marginBottom: i < steps.length - 1 ? "48px" : "0",
              }}
            >
              <div
                style={{
                  fontFamily: "monospace",
                  fontSize: "13px",
                  fontWeight: 600,
                  color: "#a78bfa",
                  letterSpacing: "0.05em",
                  paddingTop: "4px",
                }}
              >
                {step.num}
              </div>
              <div>
                <h3
                  style={{
                    fontSize: "22px",
                    fontWeight: 700,
                    letterSpacing: "-0.03em",
                    marginBottom: "10px",
                  }}
                >
                  {step.title}
                </h3>
                <p
                  style={{
                    fontSize: "15px",
                    lineHeight: 1.7,
                    color: "rgba(232,232,240,0.45)",
                  }}
                >
                  {step.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section
        style={{
          margin: "0 48px 120px",
          borderRadius: "24px",
          background:
            "linear-gradient(135deg, rgba(167,139,250,0.15) 0%, rgba(56,189,248,0.1) 100%)",
          border: "1px solid rgba(167,139,250,0.2)",
          padding: "80px 60px",
          textAlign: "center",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            top: "-100px",
            left: "50%",
            transform: "translateX(-50%)",
            width: "600px",
            height: "400px",
            background:
              "radial-gradient(ellipse, rgba(167,139,250,0.15) 0%, transparent 70%)",
            pointerEvents: "none",
          }}
        />
        <h2
          style={{
            fontSize: "clamp(32px, 5vw, 52px)",
            fontWeight: 900,
            letterSpacing: "-0.04em",
            marginBottom: "20px",
            position: "relative",
          }}
        >
          Your team deserves
          <br />
          <span
            style={{
              background: "linear-gradient(135deg, #a78bfa, #38bdf8)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            better tools.
          </span>
        </h2>
        <p
          style={{
            fontSize: "16px",
            color: "rgba(232,232,240,0.5)",
            maxWidth: "420px",
            margin: "0 auto 40px",
            lineHeight: 1.6,
            position: "relative",
          }}
        >
          Join 12,000+ teams already building the future with Nova.
        </p>
        <button
          style={{
            background: "linear-gradient(135deg, #a78bfa, #38bdf8)",
            color: "#050510",
            border: "none",
            borderRadius: "10px",
            padding: "16px 36px",
            fontSize: "15px",
            fontWeight: 700,
            cursor: "pointer",
            position: "relative",
          }}
        >
          Start free — no card needed
        </button>
      </section>
    </div>
  );
}
